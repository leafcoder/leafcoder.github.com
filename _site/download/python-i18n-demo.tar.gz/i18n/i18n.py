#coding: utf-8
import gettext

gettext.install('lang', './locale', unicode=False)
gettext.translation('lang', './locale', languages=['cn']).install(True)
print _('hello')
