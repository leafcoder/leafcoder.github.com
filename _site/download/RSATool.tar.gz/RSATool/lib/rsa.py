def genrsa(bits=1024):
    result = Popen(['openssl', 'genrsa', '%d' % bits],
            stdin=PIPE, stdout=PIPE, stderr=PIPE)
    data = result.stdout.read();  result.stdout.close()
    result = Popen(['openssl', 'rsa', '-text', '-noout'],
            stdin=PIPE, stdout=PIPE, stderr=PIPE)
    result.stdin.write(data);  result.stdin.close()
    data = result.stdout.read();  result.stdout.close()
    matched = rsa_text_noout(data)
    if matched is None:
        raise RuntimeError('openssl unknow error')
    i, n, i, e, i, i, i, i, i = matched.groups()
    e = int(''.join(e.split()).replace(':', ''), 16)
    n = int(''.join(n.split()).replace(':', ''), 16)
    return e, n

def rsaopen(fn):
    file_in = open(fn, 'r')
    data = file_in.read();  file_in.close()
    result = Popen(['openssl', 'rsa', '-text', '-noout'],
            stdin=PIPE, stdout=PIPE, stderr=PIPE)
    result.stdin.write(data);  result.stdin.close()
    data = result.stdout.read();  result.stdout.close()
    matched = rsa_text_noout(data)
    if matched is None:
        raise RuntimeError('openssl unknow error')
    i, n, i, e, i, i, i, i, i = matched.groups()
    e = int(''.join(e.split()).replace(':', ''), 16)
    n = int(''.join(n.split()).replace(':', ''), 16)
    return e, n

def encrypt(pubkey, s):
    i = pow(int(b2a_hex(s), 16), 0x10001, pubkey)
    result = array('c')
    while i:
        i, c = divmod(i, 256)
        result.append(chr(c))
    return ''.join(reversed(result))

def decrypt(prikey, pubkey, s):
    i = pow(int(b2a_hex(s), 16), prikey, pubkey)
    result = array('c')
    while i:
        i, c = divmod(i, 256)
        result.append(chr(c))
    return ''.join(reversed(result))

def box(s):
    s1 = sha1(s).digest()
    s2 = md5(s).digest()
    z = range516()
    x11 = x21 = 0
    y1 = len(s1)
    y2 = len(s2)
    for i in xrange(256):
        j = i + 258
        x11 = (x11 + z[i] + ord(s1[i % y1])) % 256
        x21 = (x21 + z[j] + ord(s2[i % y2])) % 256
        x22 = x21 + 258
        z[i], z[x11], z[j], z[x22] = z[x11], z[i], z[x22], z[j]
    return z

def crypt(z, s):
    r = array('c')
    x11, y11, x21, y21 = z[256], z[257], z[514], z[515]
    for c in s:
        x11 = (x11 + 1) % 256
        x21 = (x21 + 1) % 256
        x22 = x21 + 258
        y11 = (y11 + z[x11]) % 256
        y21 = (y21 + z[x22]) % 256
        y22 = y21 + 258
        z[x11], z[y11], z[x22], z[y22] = z[y11], z[x11], z[y22], z[x22]
        r.append(chr(ord(c) ^ z[(z[x11] + z[y11]) % 256] ^ \
                    z[(z[x22] + z[y22]) % 256 + 258]))
    z[256], z[257], z[514], z[515] = x11, y11, x21, y21
    return r.tostring()

from array import array
range516 = range(516)
for i in xrange(256, 516):
    range516[i] -= 258
range516[256] = range516[257] = range516[514] = range516[515] = 0
range516 = array('i', range516).__copy__

import re
rsa_text_noout = re.compile((
r'^private-key:(.*)\nmodulus:(.*)\npublicexponent:(.*)\nprivateexponent:(.*'
r')\nprime1:(.*)\nprime2:(.*)\nexponent1:(.*)\nexponent2:(.*)\ncoefficient:'
r'(.*)$'), re.I|re.S).match

from binascii import b2a_hex
from hashlib import sha1, md5
from subprocess import Popen, PIPE

if '__main__' == __name__:
    prikey, pubkey = genrsa(1024)
    rc4key = 'random string'
    print 'RSA:'
    print `encrypt(pubkey, rc4key)`
    #print `decrypt(prikey, pubkey, encrypt(pubkey, rc4key))`
    print 'RC4:'
    z1 = box(rc4key)
    z2 = box(rc4key)
    print len(z1)
    print `crypt(z2, crypt(z1, 'hello world!'))`
