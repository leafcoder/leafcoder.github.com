#!/usr/bin/python
#-*- coding: utf-8 -*-

import sys; reload(sys)
sys.setdefaultencoding('utf-8')

def genrsa(bits=1024):
    result = Popen(['openssl', 'genrsa', '%d' % bits],
            stdin=PIPE, stdout=PIPE, stderr=PIPE)
    data = result.stdout.read();  result.stdout.close()
    result = Popen(['openssl', 'rsa', '-text', '-noout'],
            stdin=PIPE, stdout=PIPE, stderr=PIPE)
    result.stdin.write(data);  result.stdin.close()
    data = result.stdout.read();  result.stdout.close()
    matched = rsa_text_noout(data)
    if matched is None:
        raise RuntimeError('openssl unknow error')
    i, n, i, e, i, i, i, i, i = matched.groups()
    e = int(''.join(e.split()).replace(':', ''), 16)
    n = int(''.join(n.split()).replace(':', ''), 16)
    return e, n

def rsaopen(fn):
    file_in = open(fn, 'r')
    data = file_in.read();  file_in.close()
    result = Popen(['openssl', 'rsa', '-text', '-noout'],
            stdin=PIPE, stdout=PIPE, stderr=PIPE)
    result.stdin.write(data);  result.stdin.close()
    data = result.stdout.read();  result.stdout.close()
    matched = rsa_text_noout(data)
    if matched is None:
        raise RuntimeError('openssl unknow error')
    i, n, i, e, i, i, i, i, i = matched.groups()
    e = int(''.join(e.split()).replace(':', ''), 16)
    n = int(''.join(n.split()).replace(':', ''), 16)
    return e, n

def encrypt(pubkey, s):
    i = pow(int(b2a_hex(s), 16), 0x10001, pubkey)
    result = array('c')
    while i:
        i, c = divmod(i, 256)
        result.append(chr(c))
    return ''.join(reversed(result))

def decrypt(prikey, pubkey, s):
    i = pow(int(b2a_hex(s), 16), prikey, pubkey)
    result = array('c')
    while i:
        i, c = divmod(i, 256)
        result.append(chr(c))
    return ''.join(reversed(result))

def box(s):
    s1 = sha1(s).digest()
    s2 = md5(s).digest()
    z = range516()
    x11 = x21 = 0
    y1 = len(s1)
    y2 = len(s2)
    for i in xrange(256):
        j = i + 258
        x11 = (x11 + z[i] + ord(s1[i % y1])) % 256
        x21 = (x21 + z[j] + ord(s2[i % y2])) % 256
        x22 = x21 + 258
        z[i], z[x11], z[j], z[x22] = z[x11], z[i], z[x22], z[j]
    return z

def crypt(z, s):
    r = array('c')
    x11, y11, x21, y21 = z[256], z[257], z[514], z[515]
    for c in s:
        x11 = (x11 + 1) % 256
        x21 = (x21 + 1) % 256
        x22 = x21 + 258
        y11 = (y11 + z[x11]) % 256
        y21 = (y21 + z[x22]) % 256
        y22 = y21 + 258
        z[x11], z[y11], z[x22], z[y22] = z[y11], z[x11], z[y22], z[x22]
        r.append(chr(ord(c) ^ z[(z[x11] + z[y11]) % 256] ^ \
                    z[(z[x22] + z[y22]) % 256 + 258]))
    z[256], z[257], z[514], z[515] = x11, y11, x21, y21
    return r.tostring()

from array import array
range516 = range(516)
for i in xrange(256, 516):
    range516[i] -= 258
range516[256] = range516[257] = range516[514] = range516[515] = 0
range516 = array('i', range516).__copy__

import re
rsa_text_noout = re.compile((
r'^private-key:(.*)\nmodulus:(.*)\npublicexponent:(.*)\nprivateexponent:(.*'
r')\nprime1:(.*)\nprime2:(.*)\nexponent1:(.*)\nexponent2:(.*)\ncoefficient:'
r'(.*)$'), re.I|re.S).match

from binascii import b2a_hex
from hashlib import sha1, md5
from subprocess import Popen, PIPE

import base64
from uuid import uuid4
from PySide import QtGui, QtCore
from ConfigParser import ConfigParser

rsa_key_path = 'rsa.key'

try:
    config = ConfigParser()
    config.read(rsa_key_path)
    pri_key = config.getint('RSA', 'private_key')
    pub_key = config.getint('RSA', 'public_key')
    try:
        sender_pub_key = config.getint('Sender', 'public_key')
    except:
        sender_pub_key = ''
except:
    pri_key, pub_key = genrsa(1024)
    config = ConfigParser()
    config.add_section('RSA')
    config.set('RSA', 'private_key', pri_key)
    config.set('RSA', 'public_key', pub_key)
    config.add_section('Sender')
    config.set('Sender', 'public_key', '')
    config.write(open(rsa_key_path, 'w'))
    sender_pub_key = ''

class RSAFrame(QtGui.QMainWindow):
    def __init__(self):
        super(RSAFrame, self).__init__()
        self.init_ui()

    def init_ui(self):
        menubar = self.menuBar()

        exit = QtGui.QAction(u'关闭', self)
        exit.triggered.connect(self.close)
        filemenu = menubar.addMenu(u'文件')
        filemenu.addAction(exit)

        encrypt_file = QtGui.QAction(u'加密文件', self)
        encrypt_file.triggered.connect(self.encrypt_file)

        decrypt_file = QtGui.QAction(u'解密文件', self)
        decrypt_file.triggered.connect(self.decrypt_file)

        encry_menu = menubar.addMenu(u'RSA加密')
        encry_menu.addAction(encrypt_file)
        encry_menu.addAction(decrypt_file)

        generate_key = QtGui.QAction(u'重新生成密钥', self)
        generate_key.triggered.connect(self.generate_rsa_key)

        save_sender_pub_key = QtGui.QAction(u'设置对方公钥', self)
        save_sender_pub_key.triggered.connect(self.save_sender_pub_key)

        rsakey_menu = menubar.addMenu(u'密钥')
        rsakey_menu.addAction(generate_key)
        rsakey_menu.addAction(save_sender_pub_key)

        self.tab_widget = QtGui.QTabWidget(self)

        self.encry_widget = RSAEncrypt()
        self.tab_widget.addTab(self.encry_widget, u'加密')
        self.decry_widget = RSADecrypt()
        self.tab_widget.addTab(self.decry_widget, u'解密')

        self.setCentralWidget(self.tab_widget)
        self.setWindowTitle(u'RSA 加解密')
        self.show()

    def encrypt_file(self):
        txt_sender_pubkey  = self.encry_widget.txt_sender_pubkey
        pub_key = txt_sender_pubkey.toPlainText().encode('utf-8')
        if pub_key.strip() == '':
            return QtGui.QMessageBox.about(self, u'提示', 
                u'''请先设置对方公钥！''')
        pub_key = int(pub_key)

        filename, _ = QtGui.QFileDialog.getOpenFileName(
            self, u'请选择要用加密的文件', '.')
        fileobj = open(filename, 'rb')
        s = fileobj.read()
        fileobj.close()

        rc4_key = uuid4().hex
        z = box(rc4_key)
        s = crypt(z, s)
        s = ''.join((encrypt(pub_key, rc4_key), s))

        filename, _ = QtGui.QFileDialog.getSaveFileName(
            self, u'保存加密后文件', filename + '.encrypted')
        fileobj = open(filename, 'wb')
        fileobj.write(s)
        fileobj.close()
    
    def decrypt_file(self):
        filename, _ = QtGui.QFileDialog.getOpenFileName(
            self, u'请选择要解密的文件', '.')
        fileobj = open(filename, 'rb')
        s = fileobj.read()
        fileobj.close()

        txt_self_pubkey  = self.decry_widget.txt_self_pubkey
        pub_key = int(txt_self_pubkey.toPlainText().encode('utf-8'))
        rc4_key = decrypt(pri_key, pub_key, s[:128])
        z = box(rc4_key)
        s = crypt(z, s[128:])

        filename, _ = QtGui.QFileDialog.getSaveFileName(
            self, u'保存解密后文件', filename + '.decrypted')
        fileobj = open(filename, 'wb')
        fileobj.write(s)
        fileobj.close()

    def generate_rsa_key(self):
        pri_key, pub_key = genrsa(1024)
        config.set('RSA', 'private_key', pri_key)
        config.set('RSA', 'public_key' , pub_key)
        config.write(open(rsa_key_path, 'w'))

        globals()['pub_key'], globals()['pri_key'] = pub_key, pri_key
        self.decry_widget.txt_self_pubkey.setText(str(pub_key))
        QtGui.QMessageBox.about(self, u'重新生成密钥', 
            u'''成功重新生成 RSA 密钥！密钥值见 rsa.key 文件。''')

    def save_sender_pub_key(self):
        text, ok = QtGui.QInputDialog.getText(self, u"请输入对方公钥",
            u"对方公钥:", QtGui.QLineEdit.Normal)
        if ok and text != '':
            try:
                text = int(text)
                self.encry_widget.txt_sender_pubkey.setText(str(text))
                globals()['sender_pub_key'] = text
                config.set('Sender', 'public_key', text)
                config.write(open(rsa_key_path, 'w'))
            except:
                return QtGui.QMessageBox.about(self, 
                    u'设置对方公钥', u'''公钥数据有误，请检查输入''')

class RSADecrypt(QtGui.QWidget):
    def __init__(self):
        super(RSADecrypt, self).__init__()
        self.init_ui()

    def init_ui(self):
        self.gridlayout = gridlayout = QtGui.QGridLayout(self)

        self.lbl_self_pubkey = QtGui.QLabel(u'我的公钥：')
        gridlayout.addWidget(self.lbl_self_pubkey, 0, 0, 1, 3)
        self.txt_self_pubkey = QtGui.QTextEdit()
        self.txt_self_pubkey.setReadOnly(True)
        gridlayout.addWidget(self.txt_self_pubkey, 1, 0, 1, 3)

        self.lbl_rsa = QtGui.QLabel(u'RSA 密文：')
        gridlayout.addWidget(self.lbl_rsa, 2, 0)
        self.txt_rsa = QtGui.QTextEdit()
        gridlayout.addWidget(self.txt_rsa, 3, 0, 2, 1)

        self.lbl_origin = QtGui.QLabel(u'明文：')
        gridlayout.addWidget(self.lbl_origin, 2, 2)
        self.txt_origin = QtGui.QTextEdit()
        gridlayout.addWidget(self.txt_origin, 3, 2, 2, 1)

        self.btn_decrypt = QtGui.QPushButton(u'解密 >>')
        gridlayout.addWidget(self.btn_decrypt, 3, 1)
        self.btn_decrypt.clicked.connect(self.decrypt)

        self.txt_self_pubkey.setText(str(pub_key))
        self.show()

    def decrypt(self):
        pub_key = int(self.txt_self_pubkey.toPlainText().encode('utf-8'))
        s = self.txt_rsa.toPlainText().encode('utf-8')
        s = base64.decodestring(s)
        rc4_key = decrypt(pri_key, pub_key, s[:128])
        z = box(rc4_key)
        s = crypt(z, s[128:])
        s = s.decode('utf-8')
        self.txt_origin.setText(s)

class RSAEncrypt(QtGui.QWidget):
    def __init__(self):
        super(RSAEncrypt, self).__init__()
        self.init_ui()

    def init_ui(self):
        self.gridlayout = gridlayout = QtGui.QGridLayout(self)

        self.lbl_sender_pubkey = QtGui.QLabel(u'对方公钥：')
        gridlayout.addWidget(self.lbl_sender_pubkey, 0, 0, 1, 3)
        
        self.txt_sender_pubkey = QtGui.QTextEdit()
        self.txt_sender_pubkey.setReadOnly(True)
        gridlayout.addWidget(self.txt_sender_pubkey, 1, 0, 1, 3)

        self.lbl_origin = QtGui.QLabel(u'明文：')
        gridlayout.addWidget(self.lbl_origin, 2, 0)
        self.txt_origin = QtGui.QTextEdit()
        gridlayout.addWidget(self.txt_origin, 3, 0, 2, 1)

        self.lbl_rsa = QtGui.QLabel(u'RSA 密文：')
        gridlayout.addWidget(self.lbl_rsa, 2, 2)
        self.txt_rsa = QtGui.QTextEdit()
        gridlayout.addWidget(self.txt_rsa, 3, 2, 2, 1)

        self.btn_encrypt = QtGui.QPushButton(u'加密 >>')
        self.btn_encrypt.clicked.connect(self.encrypt)
        gridlayout.addWidget(self.btn_encrypt, 3, 1)

        self.txt_sender_pubkey.setText(str(sender_pub_key))
        self.show()

    def encrypt(self):
        pub_key = self.txt_sender_pubkey.toPlainText().encode('utf-8')
        if pub_key.strip() == '':
            return QtGui.QMessageBox.about(self, u'提示', 
                u'''请先设置对方公钥！''')
        pub_key = int(pub_key)

        s = self.txt_origin.toPlainText().encode('utf-8')
        rc4_key = uuid4().hex
        z = box(rc4_key)
        s = crypt(z, s)
        s = ''.join((encrypt(pub_key, rc4_key), s))
        s = base64.encodestring(s)
        self.txt_rsa.setText(s)

def main():
    app = QtGui.QApplication(sys.argv)
    ras_tool = RSAFrame()
    sys.exit(app.exec_())

main()
